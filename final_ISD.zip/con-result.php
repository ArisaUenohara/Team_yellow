<?php
require_once('config.php');
session_start();

// セッションからユーザー情報を取得
if (!isset($_SESSION['EMAIL'])) {
    // ログインしていない場合、ログインページにリダイレクト
    header('Location: index.php');
    exit;
}

$classResult = "診断結果が見つかりませんでした。";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // データベースへ接続する
        $handle = new PDO(DSN, DB_USER, DB_PASS);
        $handle->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // POSTデータを取得
        $className = $_POST['userClass'] ?? '';
        $userEmail=$_SESSION['EMAIL'];

        // クラスに対応する結果を取得
        $stmt = $handle->prepare("SELECT result FROM class_group WHERE email=:email AND class = :class");
        $stmt->bindParam(':class', $className, PDO::PARAM_STR);
        $stmt->bindParam(':email', $userEmail, PDO::PARAM_STR);
        $stmt->execute();

        // 結果を取得
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($result) {
            $classResult = $result['result'];
        }else {
            echo "エラーが発生しました。";
        }
    } catch (PDOException $e) {
        $classResult = "エラーが発生しました: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>結果</title>
    <link rel="stylesheet" href="con-result.css">
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const userClass = localStorage.getItem('userClass') || "未設定";
           // userClass-display 要素を取得
            const userClassElement = document.getElementById('userClass-display');
            
            // 要素が存在する場合のみ値を設定
            if (userClassElement) {
                userClassElement.textContent = userClass || "未設定"; // フォールバックに「未設定」を使用
            }
            // クラスをフォームにセットしてサーバーに送信
            if (userClass !== "未設定") {
                const form = document.getElementById('classForm');
                const input = document.getElementById('classInput');
                input.value = userClass;
                form.submit();
            } else {
                document.getElementById('result-description').textContent = "クラスが未設定です。";
            }
        });
    </script>
</head>
<body>
    <div class="container">
        <h1>あなたの診断結果</h1>
        <h2>クラス：<span id="userClass-display"></span></h2>
        <p id="result-description"><?php echo htmlspecialchars($classResult, ENT_QUOTES, 'UTF-8'); ?></p>

        <!-- クラスを送信するためのフォーム -->
        <form id="classForm" method="POST" action="con-result.php" style="display:none;">
            <input type="hidden" id="classInput" name="userClass">
        </form>
    </div>
</body>
</html>

