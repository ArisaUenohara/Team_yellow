<!DOCTYPE html>
<html lang="ja">

<head>
  <meta charset="UTF-8" content="width=device-width, initial-scale=1.0">
  <title>グループ活動マッチングサービス</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Helvetica Neue', Arial, sans-serif;
    }

    body {
      background-color: #faf7f2;
      color: #5c4f3d;
      line-height: 1.6;
    }

    .container {
      max-width: 800px;
      margin: 0 auto;
      padding: 40px 20px;
    }

    .header {
      text-align: center;
      margin-bottom: 60px;
    }

    .header h1 {
      color: #796957;
      font-size: 2.5em;
      margin-bottom: 20px;
    }

    .header p {
      color: #8b7355;
      font-size: 1.2em;
      line-height: 1.8;
    }

    .section {
      background: #fffcf7;
      border-radius: 12px;
      padding: 30px;
      margin-bottom: 30px;
      box-shadow: 0 2px 15px rgba(164, 146, 124, 0.1);
    }

    .section h2 {
      color: #796957;
      margin-bottom: 20px;
      font-size: 1.8em;
      border-bottom: 2px solid #f0e6d9;
      padding-bottom: 10px;
    }

    .section p {
      color: #6b5d4e;
      font-size: 1.1em;
      margin-bottom: 15px;
    }

    .feature-list {
      list-style: none;
      padding: 0;
    }

    .feature-list li {
      padding: 10px 0;
      color: #6b5d4e;
      font-size: 1.1em;
      display: flex;
      align-items: center;
    }

    .feature-list li:before {
      content: "•";
      color: #c1a88b;
      font-weight: bold;
      margin-right: 10px;
    }

    .highlight {
      background-color: #f5efe6;
      padding: 20px;
      border-radius: 8px;
      margin: 20px 0;
      border: 1px solid #e8dfd3;
    }

    .button {
      background-color: #8b7355;
      text-align:center;
      color: white;
      width: 80%;
      padding: 1rem;
      border: none;
      border-radius: 12px;
      cursor: pointer;
      font-size: 1rem;
      margin: 0.5rem 0;
      transition: opacity 0.3s;
    }

    @media (max-width: 600px) {
      .container {
        padding: 20px 10px;
      }

      .header h1 {
        font-size: 2em;
      }
    }
  </style>
</head>

<body>
  <div class="container">
    <header class="header">
      <h1>グループ活動マッチングサービス</h1>
      <p>自分に合ったメンバーと効率的で楽しいグループ活動を実現</p>
    </header>

    <section class="section">
      <h2>サービス対象</h2>
      <div class="highlight">
        <p>グループ分けに不安を感じている方</p>
      </div>
      <ul class="feature-list">
        <li>チーム作りに悩んでいる方</li>
        <li>効率的なグループ活動を目指す方</li>
        <li>相性の良いメンバーと活動したい方</li>
      </ul>
    </section>

    <section class="section">
      <h2>サービスの特徴</h2>
      <div class="highlight">
        <p>仕事のスタイルを理解し、最適なチーム編成をサポート</p>
      </div>
      <ul class="feature-list">
        <li>個人の作業スタイルを分析するテストを提供</li>
        <li>自己理解を深める詳細なレポート</li>
        <li>相性の良いメンバーとのマッチング</li>
        <li>効率的なチーム編成のサポート</li>
      </ul>
    </section>
  </div>
  <input type="button" class="buttton" onclick="location.href ='index.php'">使ってみる</input>
</body>

</html>