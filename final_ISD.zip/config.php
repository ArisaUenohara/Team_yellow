<?php

//ini_set('display_errors', 1);

define('DSN', 'mysql:host=mysql1025.onamae.ne.jp;dbname=57hwa_student');
define('DB_USER', '57hwa_student');
define('DB_PASS', 'Ixia2leaf!');