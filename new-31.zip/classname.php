<?php
session_start();
// セッションからユーザー情報を取得
if (!isset($_SESSION['EMAIL'])) {
    // ログインしていない場合、ログインページにリダイレクト
    header('Location: index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="ja">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>クラス名を入力</title>
    <style>
   body {
    font-family: 'Arial', sans-serif;
    background-color: #faf7f2;
    display: flex;
    justify-content: center;
    align-items: center;
    height:100vh;
}

  .container {
    text-align:center;
    background: white;
    padding: 20px 100px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    width: 450px;
}

input {
    background-color: #f5f5f5;
    width: 60%;
    padding: 0.8rem 1.2rem;
    border-radius: 2.5rem;
    margin-bottom: 1rem;
    align-items: center;
    text-align: left;
    transition: opacity 0.3s;
    border: none;
    background: none;
  }

  .btn {
  display: inline-block;
  text-align: center;
  position: relative;
  width: 350px;
  margin: 20px auto;
  padding: 15px 30px;
  background-color: #847577;
  color: #f4f4f4;
  text-decoration: none;
  border-radius: 4px;
  box-shadow: 0px 0px 0px 5px #C4A59E;
  transition: background-color 0.3s;
  border: none;
}

.btn:hover {
  background-color: #5C4B51;
}

.error-message {
    color: red;
    font-size: 14px;
    margin-top: 10px;
    text-align: center;
}

.button {
    width: 250px;
    padding: 15px;
    font-size:50px;
    background-color: #8b7355;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
}
.button:hover {
    background-color: #8b7355;
}

.before {
  display: inline-block;
  text-align: center;
  position: relative;
  width: 150px;
  margin: 20px auto;
  padding: 15px 30px;
  background-color: #847577;
  color: #f4f4f4;
  text-decoration: none;
  border-radius: 4px;
  box-shadow: 0px 0px 0px 5px #C4A59E;
  transition: background-color 0.3s;
  border: none;
  margin-bottom: 40px;
}

.before:hover {
  background: #5C4B51;
  color: white;
}
    </style>
</head>
<body>
<div class="container">
      <h4>クラス名を入力してください</h4>
        <div class="class-input-container">
          <input type="text" id="classInput" class="class-input" placeholder="クラス名を入力">
          <div id="errorMessage" class="error-message"></div>
      </div>
        <button class="btn" id="navigateButton" href="judge.php" disabled>質問に進む</button>
      <a class="before" href="mypage.php">マイページに戻る</a>
    </div>
</body>
<script>
        const classInput = document.getElementById('classInput');
        const navigateButton = document.getElementById('navigateButton');

        // 入力の検知
        classInput.addEventListener('input', () => {
            const classValue = classInput.value.trim();
            navigateButton.disabled = classValue === '';
        });

        // ボタンを押したときにlocalStorageに保存し、次のページへ移動
        navigateButton.addEventListener('click', () => {
            const classValue = classInput.value.trim();
            if (classValue) {
                localStorage.setItem('userClass', classValue);
                window.location.href = 'judge.php';
            }
        });
    </script>