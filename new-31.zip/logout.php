<?php
session_start();
$output = '';
if (isset($_SESSION["EMAIL"])) {
  $output = 'Logoutしました。';
} else {
  $output = 'SessionがTimeoutしました。';
}
// Clear session variables
$_SESSION = array();
// Delete session cookies
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}
// Destroy session
@session_destroy();

?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ログアウト</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background-color: #f4f2ef;
            color: #4a3c31;
        }
        .message {
            font-size: 1.5rem;
            margin-bottom: 2rem;
        }
        .logout {
            background-color: #8b7355;
            color: white;
            width: 200px;
            padding: 1rem;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font-size: 1rem;
            margin: 0.5rem 0;
            transition: transform 0.3s, opacity 0.3s;
        }
        .logout:hover {
            transform: translateY(-3px);
            opacity: 0.9;
        }
        .logout:active {
            transform: translateY(1px);
            opacity: 1;
        }
    </style>
</head>
<body>
    <div class="message">
        <?php echo $output; ?>
    </div>
    <button class="logout" onclick="location.href='index.php'" type="button">ログイン</button>
</body>
</html>
